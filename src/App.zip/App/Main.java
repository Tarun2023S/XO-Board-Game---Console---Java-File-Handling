package App;
import java.util.*;
public class Main {
	
	private static int validChoices() {
		int choice=0 ;
		System.out.println("\t\t"+printBoundary(20));
		System.out.println("\n\t\t Enter Your Choice\n");
		System.out.println("\t\t"+printBoundary(20));
		System.out.println("  1. Play game\n  2. Score Card\n  3. Exit\n");
		lastPlayedGameInfo();
		Scanner sc = new Scanner(System.in);
		try {
		 choice = sc.nextInt();	
		}
		catch(Exception e) {
			System.out.println(" Please enter a valid choice\n");
			validChoices();
		}
		return choice;
	}
	
	private static String printBoundary(int a) {
		return ""+String.valueOf('-').repeat(a);
	}
	
	private static void lastPlayedGameInfo() {
		System.out.println("\t\t"+printBoundary(26));
		System.out.println("\t\t  Last Played Game Info");
		System.out.println("\t\t"+printBoundary(26));
		System.out.println();
		if(GameManager.stackHistory.isEmpty()) {
			System.out.println("\t\tThere were no last played games..");
		}
		else {
			
			System.out.println(""+printBoundary(13)+"\t\t"+printBoundary(17)+"\t"+printBoundary(10));
			System.out.println(" Player name\t\t  Opponent name\t\t  Winner");
			System.out.println(""+printBoundary(13)+"\t\t"+printBoundary(17)+"\t"+printBoundary(10));
			GameManager.Log obj = GameManager.stackHistory.peek();
			System.out.println("\t"+obj.p1.getName()+"\t\t\t"+obj.p2.getName()+"\t\t  "+obj.whoWon.getName());
		}
	}
	
	public static void main(String[] args) {
		boolean loop = true;
		GameManager gm = new GameManager();
		Scanner sc = new Scanner(System.in);
		while(loop) {
//			System.out.println("\t"+printBoundary(13));
//			System.out.println("\t\tGAME STARTS");
			int choice = validChoices();
			switch(choice) {
				case 1: {
					gm.playGame();
				}
				break;
				case 2: {
					
				}
				break;
				case 3: {
					System.out.println("\t\tThank you for your time..");
					loop = false;
				}
				break;
				default: {
					System.out.println("Please enter a valid case number");
				}
				break;
			}
		}

	}

}
