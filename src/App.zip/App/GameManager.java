package App;
import java.util.*;

public class GameManager {
	static class Log {
		Player p1, p2, whoWon;
		public Log(Player p1, Player p2, Player whoWon) {
			this.p1 = p1;
			this.p2 = p2;
			this.whoWon = whoWon;
		}
	}
    Map<Integer, Integer> playerWinMap;
    List<Player> listOfPlayers;
    static Stack<Log> stackHistory;
    
    public GameManager() {
        playerWinMap = new HashMap<>();
        listOfPlayers = new LinkedList<>();
        stackHistory = new Stack();
    }

    static int[][] xoArray = new int[3][3];

    private boolean checkIfPlayerExists(String name) {
        for (Player p : listOfPlayers) {
            if (p.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    void playGame() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter player 1 name");
        String player1 = sc.next();
//        if (checkIfPlayerExists(player1)) {
//            System.out.println("\t\tThat name already exists..\n\t\tPlease try entering a different name..");
//            playGame();
//        }
        while(checkIfPlayerExists(player1)) {
        	System.out.println("\t\tThat name already exists..\n\t\tPlease try using a different name..");
        	player1 = sc.next();
        }
//        playGame();
//        playGame();
        Player p1 = new Player(player1);
        listOfPlayers.add(p1);
        System.out.println("Enter player 2 name");
        String player2 = sc.next();
//        if (checkIfPlayerExists(player2)) {
//            System.out.println("\t\tThat name already exists..\n\t\tPlease try entering a different name..");
//            playGame();
//        }
        while(checkIfPlayerExists(player2)) {
        	System.out.println("\t\tThat name already exists..\n\t\tPlease try entering a different name..");
        	player2 = sc.next();
        }
//        playGame();
        Player p2 = new Player(player2);
        listOfPlayers.add(p2);
        startGame(p1, p2);
    }

    protected void startGame(Player p1, Player p2) {
        Scanner sc = new Scanner(System.in);
        showMatrix();
        
        for (int i = 0; i < 9; i++) {
            Player currentPlayer = (i % 2 == 0) ? p1 : p2;
            System.out.println("\n\tEnter the choice for " + currentPlayer.getName() +
                    " (As in coordinates => r,c )\n");
            String coordinate = sc.next();
            System.out.println("cord:"+coordinate.split(",")[0]);
            int row = Integer.valueOf(coordinate.split(",")[0]);
            int col = Integer.valueOf(coordinate.split(",")[1]);
//            if(coordinate.split(",")[0]) >= 48) {
//            	
//            }
//            System.out.println("cord:"+coordinate.split(",")[0]);
            System.out.println("r: "+row+", c: "+col);
//            System.out.println(""+row+", "+col);
            while (!isValid(row, col)) {
                System.out.println("\tPlease select a valid choice.");
                coordinate = sc.next();
                row = Integer.valueOf(coordinate.split(",")[0]);
                col = Integer.valueOf(coordinate.split(",")[1]);
            }
            
//            if(i%2==0) {
//            	xoArray[row][col] = 1;
//            } else {
//            	xoArray[row][col] = 2;
//            }
            xoArray[row][col] = (i % 2 == 0) ? 1 : 2;

            showMatrix();

            if (check(row, col)) {
                System.out.println(currentPlayer.getName() + " wins");
                if(p2.getName().equals(currentPlayer.getName())) {
                	stackHistory.push(new Log(currentPlayer, p1, currentPlayer));
                } else {
                	stackHistory.push(new Log(currentPlayer, p2, currentPlayer));
                }
                
                if(playerWinMap.get(currentPlayer.getName())==null) {
                	playerWinMap.put(currentPlayer.getPlayerId(), 1);
                }
                else {
                	int totalWins = playerWinMap.get(currentPlayer);
                	playerWinMap.put(currentPlayer.getPlayerId(), totalWins + 1);
                }
//                playerWinMap.getOrDefault(currentPlayer.getPlayerId(), new Player());
                clearXOBoard();
                showMatrix();
                return;
            }
            
            //showMatrix();
        }

        System.out.println("\n It's a DRAW !!");
    }

    private boolean isValid(int row, int col) {
        if (row >= 0 && row < 3 && col >= 0 && col < 3 && xoArray[row][col] == 0) {
            return true;
        }
        return false;
    }

    private boolean check(int row, int col) {
    	// Check the rows from left - ri8
    	int countR = 0;
    	for(int i=0;i<2;i++) {
    		if(xoArray[row][i] == xoArray[row][i+1]) {
    			countR++;
    		}
    	}
    	
//    	System.out.println("X/O:");
//    	System.out.println(Arrays.toString(xoArray));
//    	System.out.println();
    	if(countR==2) return true;
    	
        // Check the columns from top - bot
    	int countC = 0;
    	for(int i=0;i<2;i++) {
    		if(xoArray[i][col] == xoArray[i+1][col] && xoArray[i][col] != 0 && xoArray[i+1][col] != 0) {
    			countC++;
    		}
    	}
    	if(countC==2) return true;

        // Check the diagonals from cross or mid
        if ((xoArray[0][0] == xoArray[1][1] && xoArray[1][1] == xoArray[2][2]
                || xoArray[0][2] == xoArray[1][1] && xoArray[1][1] == xoArray[2][0]) && xoArray[1][1] != 0) {
            return true;
        }

        return false;
    }

    private void showMatrix() {
//    	System.out.println(Arrays.toString(xoArray));
        for (int i = 0; i < xoArray.length; i++) {
            for (int j = 0; j < xoArray[i].length; j++) {
                if (xoArray[i][j] == 1) {
                    System.out.print("  X");
                } else if (xoArray[i][j] == 2) {
                    System.out.print("  O");
                } else {
                    System.out.print("  _");
                }
            }
            System.out.println();
        }
//    	System.out.println(Arrays.toString(xoArray));
        
    }
    
    private void clearXOBoard() {
    	for(int[] r: xoArray) {
    		for(int c: r) {
    			c = 0;
    		}
    	}
//    	System.out.println(Arrays.toString(xoArray));
    }
}


