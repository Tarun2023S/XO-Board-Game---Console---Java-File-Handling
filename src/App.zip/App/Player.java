package App;

public class Player {
	static int id = 1;
	private int playerId;
	private String name;
	
	public Player(String name) {
		this.playerId = id++;
		this.name = name;
	}
	
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
