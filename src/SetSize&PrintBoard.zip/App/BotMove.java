package App;

import java.util.Arrays;

public class BotMove {

	 int[] getBotMove(int[][] board, int botSymbol) {
        int[] result = new int[]{-1, -1};

        // Check for a winning move for the bot
        result = checkWinningMove2(board, botSymbol);

        if (result[0] == -1 && result[1] == -1) {
            // If no winning move, check for a blocking move for the player
            int playerSymbol = (botSymbol == 1) ? 2 : 1;
            result = checkWinningMove2(board, playerSymbol);
        }

        // If no winning or blocking move, choose the first available empty cell
        if (result[0] == -1 && result[1] == -1) {
            for (int i = 0; i < board.length; i++) {
                for (int j = 0; j < board[0].length; j++) {
                    if (board[i][j] == 0) {
                    	result = getNextToMaxConsecutiveTwos(board, 2);
//                        result[0] = i;
//                        result[1] = j;
                        return result;
                    }
                }
            }
        }

        return result;
    }
	
	 private int[] checkWinningMove2(int[][] board, int symbol) {
	    	int consec = 0, noOfSymbols = 0, missing = -1, gap = -1;
	    	int res[] = new int[2];
	    	res[0] = -1;
	    	res[1] = -1;
	    	int expectedNumberOfSymbols = board[0].length - 1;
	    	// ROW WISE CHECK
	    	for (int i = 0; i < board.length; i++) {
	    	    consec = 0;
	    	    noOfSymbols = 0;
	    	    missing = -1;
	    	    gap = -1;

	    	    // ROW WISE CHECK GAP
	    	    for (int j = 0; j < board[i].length; j++) {
	    	        if (board[i][j] == symbol) {
	    	            noOfSymbols++;
	    	        } else if (board[i][j] == 0) {
	    	            gap = j;
	    	        }
	    	    }

	    	    if (noOfSymbols == expectedNumberOfSymbols && gap != -1) {
	    	        System.out.println("IN gap sym");
	    	        if (board[i][gap] == 0) {
	    	            res[0] = i;
	    	            res[1] = gap;
//	    	            System.out.println("Res: Through Rgap1 " + Arrays.toString(res));
	    	            return res;
	    	        }
	    	    }
	    	}

	    	// COLUMN WISE CHECK
	    	for (int j = 0; j < board[0].length; j++) {
	    	    consec = 0;
	    	    noOfSymbols = 0;
	    	    missing = -1;
	    	    gap = -1;

	    	    // COLUMN WISE CHECK GAP
	    	    for (int i = 0; i < board.length; i++) {
	    	        if (board[i][j] == symbol) {
	    	            noOfSymbols++;
	    	        } else if (board[i][j] == 0) {
	    	            gap = i;
	    	        }
	    	    }

	    	    if (noOfSymbols == expectedNumberOfSymbols && gap != -1) {
	    	        System.out.println("IN gap sym");
	    	        if (board[gap][j] == 0) {
	    	            res[0] = gap;
	    	            res[1] = j;
	    	            return res;
	    	        }
	    	    }
	    	}

	    	// Check diagonals
	        int r=0, c=0;
	        noOfSymbols = 0;
	        int totalRows = board.length, totalCols = board[0].length;
	        int[] miss = {-1, -1};
	        System.out.println("Diag wise Check");
	        while(r<totalRows && c<totalCols) {
	        	if(board[r][c]==symbol) {
	        		noOfSymbols++;
	        	}
	        	else {
	        		miss[0] = r;
	        		miss[1] = c;
	        	}
	        	r++;
	        	c++;
	        }
	        if (noOfSymbols == expectedNumberOfSymbols && miss[0] != -1) {
		        System.out.println("IN gap sym");
		        if (board[miss[0]][miss[1]] == 0) {
		            return miss;
		        }
		    }
	        
	        r=0;
	        c=board.length-1;
	        noOfSymbols = 0;
	        miss[0] = -1;
	        miss[1] = -1;
	        System.out.println("Diag wise Check 2");
	        while(r>=0 && c>=0) {
	        	if(board[r][c]==symbol) {
	        		noOfSymbols++;
	        		System.out.println("r: "+r+", c: "+c);
	        	}
	        	else {
	        		miss[0] = r;
	        		miss[1] = c;
	        	}
	        	r++;
	        	c--;
	        }
	        
	        System.out.println("noOfSym: "+noOfSymbols);
	        if (noOfSymbols == expectedNumberOfSymbols && miss[0] != -1) {
		        System.out.println("IN gap sym");
		        if (board[miss[0]][miss[1]] == 0) {
		            return miss;
		        }
		    }
	        return res;
	    }
	 
	 private static int[] getNextToMaxConsecutiveTwos(int[][] board, int symbol) {
		    int maxConsecutiveTwos = -1;
		    int[] result = new int[]{-1, -1};

		    // Iterate over the board to find the cell with the maximum consecutive 2's
		    for (int i = 0; i < board.length; i++) {
		        for (int j = 0; j < board[0].length; j++) {
		            if (board[i][j] == 0) {
		                int consecutiveTwos = countConsecutiveTwos(board, i, j, symbol);
		                if (consecutiveTwos > maxConsecutiveTwos) {
		                    maxConsecutiveTwos = consecutiveTwos;
		                    result[0] = i;
		                    result[1] = j;
		                }
		            }
		        }
		    }

		    return result;
		}

		private static int countConsecutiveTwos(int[][] board, int row, int col, int symbol) {
		    // Count consecutive 2's horizontally, vertically, and diagonally
		    int count = 0;

		    // Check horizontally
		    for (int i = -1; i <= 1; i++) {
		        if (col + i >= 0 && col + i < board[0].length && board[row][col + i] == symbol) {
		            count++;
		        }
		    }

		    // Check vertically
		    for (int i = -1; i <= 1; i++) {
		        if (row + i >= 0 && row + i < board.length && board[row + i][col] == symbol) {
		            count++;
		        }
		    }

		    // Check diagonally
		    for (int i = -1; i <= 1; i++) {
		        for (int j = -1; j <= 1; j++) {
		            if (row + i >= 0 && row + i < board.length && col + j >= 0 && col + j < board[0].length && board[row + i][col + j] == symbol) {
		                count++;
		            }
		        }
		    }

		    return count;
		}
}

