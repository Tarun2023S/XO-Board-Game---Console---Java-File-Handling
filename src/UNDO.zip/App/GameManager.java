package App;

import java.util.*;

import App.GameManager.Log;

public class GameManager {
	private int currentSecond = 0;
	private boolean isTimeLimitExceeded = false;
    public void setCurrentSecond(int currentSecond) {
		this.currentSecond = currentSecond;
	}
    
	static class Log {
        Player p1, p2, whoWon;
        private boolean isDraw = false;
        public boolean isDraw() {
			return isDraw;
		}
		public void setDraw(boolean isDraw) {
			this.isDraw = isDraw;
		}
		public Log(Player p1, Player p2, Player whoWon) {
            this.p1 = p1;
            this.p2 = p2;
            this.whoWon = whoWon;
        }
    }

    Map<Integer, Integer> playerWinMap;
    Set<Player> listOfPlayers;
    static Stack<Log> stackHistory;

    public GameManager() {
        playerWinMap = new HashMap<>();
        listOfPlayers = new HashSet<>();
        stackHistory = new Stack<Log>();
    }

    static int[][] xoArray = new int[3][3];

    private Player checkIfPlayerExists(String name) {
        Player t = null;
        for (Player p : listOfPlayers) {
            if (p.getName().equals(name)) {
                t = p;
                return t;
            }
        }
        return t;
    }

    void playGame() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        boolean validChoice = false;
        while(!validChoice) {
        	try {
        		System.out.println("1. Timed Game\n");
                System.out.println("2. Untimed Game\n");
                System.out.println(" Please select an option\n");
            	choice = sc.nextInt();
            	if(choice<1 || choice>2) {
            		throw new Exception();
            	}
            	else {
            		validChoice = true;
            	}
            }
            catch(Exception e) {
            	System.out.println("Please enter an valid choice");
            }
        }
        
        System.out.println("Enter player 1 name\n");
        String player1 = sc.next();

        Player p1 = checkIfPlayerExists(player1);
        if (p1 == null) {
            p1 = new Player(player1);
            listOfPlayers.add(p1);
        }

        System.out.println("Enter player 2 name\n");
        String player2 = sc.next();
        while(player1.equals(player2)) {
        	System.out.println("\nTHE TWO PLAYERS PLAYING, MUST HAVE DIFFERENT NAMES..\n");
        	System.out.println("Please try entering an Different name..\n");
        	player2 = sc.next();
        }
        Player p2 = checkIfPlayerExists(player2);
        if (p2 == null) {
            p2 = new Player(player2);
            listOfPlayers.add(p2);
        }
        
        startGame(p1, p2, choice);
    }
    
    protected int getCurrentSecond() {
    	return currentSecond;
    }
    protected void startTimer() throws TimeLimitExceededException {
//    	int currentSecond = 0;
    	for (int seconds = 0; seconds <= 30; seconds++) {
//            System.out.println("Timer: " + seconds + " seconds");
            currentSecond = seconds;
            if(currentSecond >= 30) {
            	throw new TimeLimitExceededException("Time Limit Exceeded");
            }
            try {
                // Sleep for 1 second (1000 milliseconds)
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
        }
    	
//    	return currentSecond;
    }
    protected void startGame(Player p1, Player p2, int choice) {
        Scanner sc = new Scanner(System.in);
        showMatrix();

        if(choice==1) {
        	Runnable r = new Runnable() {
    			public void run() {
    				try {
						startTimer();
					} catch (TimeLimitExceededException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						isTimeLimitExceeded = true;
//						return;
					}
    			}
    		};
        	Thread t1 = new Thread(r);
        	t1.start();        	
            
        }
        String undoChoice = "";
        for (int i = 0; i < 9; i++) {
            Player currentPlayer = (i % 2 == 0) ? p1 : p2;
            
            System.out.println("\n\tEnter the choice for " + currentPlayer.getName() +
                    " (As in coordinates => r,c )\n'U' -> FOR UNDO the Previous play");
            
            int row = 0;
            int col = 0;
            boolean validInput = false;

            String coordinate = "";
            while (!validInput) {
                try {
                	if(isTimeLimitExceeded) {
                		throw new TimeLimitExceededException("Time Limit Exceeded");
                	}
                    coordinate = sc.next();
//                    System.out.println("Cood: "+coordinate);
                    if("U".equalsIgnoreCase(coordinate)) {
                    	if(!undoChoice.isEmpty()) {
                    		row = Integer.valueOf(undoChoice.split(",")[0]);
                            col = Integer.valueOf(undoChoice.split(",")[1]);
                    		xoArray[row][col] = 0;
                    		i--;
                    		validInput = false;
                    		showMatrix();
                    		continue;
                    	}
                    }
                    row = Integer.valueOf(coordinate.split(",")[0]);
                    col = Integer.valueOf(coordinate.split(",")[1]);

                    validInput = isValid(row, col);
                    if (!validInput) {
                        System.out.println("\tPlease select a valid choice.");
                    }
                    else {
                    	System.out.println("XO I: "+i);
                        undoChoice = coordinate;
                        xoArray[row][col] = (i % 2 == 0) ? 1 : 2;
                        showMatrix();
                    }
                } 
                catch(TimeLimitExceededException e) {
                	System.out.println(e.getMessage());
                	isTimeLimitExceeded = !isTimeLimitExceeded;
                	clearXOBoard();
                	return;
                }
                catch (Exception e) {
                    System.out.println("\tInvalid input. Please enter coordinates in the format 'r,c'.");
                }
            }
            
            if(choice==1) {
            	if(getCurrentSecond()>=30) {
            		System.out.println();
            		markDraw(p1, p2);
            		return;
            	}
            	System.out.println("Cuurent Second: "+getCurrentSecond());
            }
            
            showMatrix();
            if(choice==1) {
            	if(getCurrentSecond()>=30) {
            		System.out.println("TIME LEFT: 0");
            		markDraw(p1, p2);
            		return;
            	}
            	else {
            		System.out.println("TIME LEFT: "+(30 - getCurrentSecond()));
            	}
            }
            boolean isFirstPlayer = (i%2)==0;
            if (i > 2 && check(row, col, isFirstPlayer)) {
                Player loss1 = null;
                if (currentPlayer.getName().equals(p1.getName())) {
                    loss1 = p1;
                    int loss = p1.getTotalLosses();
                    p1.setTotalLosses(loss + 1);
                } else {
                    loss1 = p2;
                    int loss = p2.getTotalLosses();
                    p2.setTotalLosses(loss + 1);
                }
                System.out.println(currentPlayer.getName() + " wins");
                if(choice==1) {
                	if(getCurrentSecond()>=30) {
                		System.out.println("TIME LEFT: 0");
                		markDraw(p1, p2);
                		return;
                	}
                	else {
                		System.out.println("TIME LEFT: "+(30 - getCurrentSecond()));
                	}
                }

                if (p2.getName().equals(currentPlayer.getName())) {
                    stackHistory.push(new Log(currentPlayer, p1, currentPlayer));
                } else {
                    stackHistory.push(new Log(currentPlayer, p2, currentPlayer));
                }

                int totalWins = playerWinMap.getOrDefault(currentPlayer.getPlayerId(), 0);
                playerWinMap.put(currentPlayer.getPlayerId(), totalWins + 1);

                System.out.println("\n\n");

                Iterator<Player> iterator = listOfPlayers.iterator();
                while (iterator.hasNext()) {
                    Player p = iterator.next();

                    String pt1 = p1.getName();
                    String pt2 = p2.getName();

                    if (p.getName().equals(pt1)) {
//                        System.out.println("In p1::" + p.getTotalGamesPayed());
                        int gamesPlayedByP1 = p.getTotalGamesPayed();
                        p.setTotalGamesPayed(gamesPlayedByP1 + 1);

                        if (loss1.getName().equals(p)) {
                            p.setTotalLosses(loss1.getTotalLosses());
                        }
                    } else if (p.getName().equals(pt2)) {
//                        System.out.println("In p2::" + p.getTotalGamesPayed());
                        int gamesPlayedByP2 = p.getTotalGamesPayed();
                        p.setTotalGamesPayed(gamesPlayedByP2 + 1);

                        if (loss1.getName().equals(p)) {
                            p.setTotalLosses(loss1.getTotalLosses());
                        }
                    }
                }

                clearXOBoard();
//                showMatrix();
                isTimeLimitExceeded = false;
                return;
            }

        }
        markDraw(p1, p2);
    }

    private void markDraw(Player p1, Player p2) {
    	if(getCurrentSecond()>=30) {
    		System.out.println(" TIME LIMIT EXCEEDED\n");
    	}
    	System.out.println("\n It's a DRAW !!");
		Iterator<Player> iterator = listOfPlayers.iterator();
        while (iterator.hasNext()) {
            Player pl = iterator.next();
            if (pl.getName().equals(p1.getName())) {
                int currentDrawsForP1 = pl.getTotalDraws();
                pl.setTotalDraws(currentDrawsForP1 + 1);
            } else if (pl.getName().equals(p2.getName())) {
                int currentDrawsForP2 = pl.getTotalDraws();
                pl.setTotalDraws(currentDrawsForP2 + 1);
            }
        }
        clearXOBoard();
        Log g = new Log(p1, p2, null);
        g.setDraw(true);
        stackHistory.push(g);
        return;
    }
    //TO CHECK, IF THE (r,c) IS WITHIN THE RANGE
    private boolean isValid(int row, int col) {
        return row >= 0 && row < 3 && col >= 0 && col < 3 && xoArray[row][col] == 0;
    }

    private boolean check(int row, int col, boolean isFirst) {
    	// Check the rows from left - ri8
    	int countR = 0;
    	for(int i=0;i<2;i++) {
    		if(isFirst && xoArray[row][i]==1) {
    			if(xoArray[row][i] == xoArray[row][i+1]) {
        			countR++;
        		}
    		}
    		else if(!isFirst&& xoArray[row][i]==2) {
    			if(xoArray[row][i] == xoArray[row][i+1]) {
        			countR++;
        		}
    		}
    		else {
    			break;
    		}
    	}
    	if(countR==2) return true;
    	
        // Check the columns from top - bottom
    	int countC = 0;
    	for(int i=0;i<2;i++) {
    		if(isFirst && xoArray[i][col]==1) {
    			if(xoArray[i][col] == xoArray[i+1][col] && xoArray[i][col] != 0 && xoArray[i+1][col] != 0) {
        			countC++;
        		}
    		}
    		else if(!isFirst&& xoArray[i][col]==2) {
    			if(xoArray[i][col] == xoArray[i+1][col] && xoArray[i][col] != 0 && xoArray[i+1][col] != 0) {
        			countC++;
        		}
    		}
    		else {
    			break;
    		}
    		
    	}
    	if(countC==2) return true;

        // Check the diagonals from cross or mid
    	int leftDiag=0, rightDiag=0;
    	int r1=0, c1=0;
    	while(r1<2 && c1<2) {
    		if(isFirst && xoArray[r1][c1]==1 && xoArray[r1][c1]==xoArray[r1+1][c1+1]) {
    			leftDiag++;
    			r1++;
    			c1++;
    		}
    		else if(!isFirst && xoArray[r1][c1]==2 && xoArray[r1][c1]==xoArray[r1+1][c1+1]) {
    			leftDiag++;
    			r1++;
    			c1++;
    		}
    		else {
    			break;
    		}
    	}
//    	
    	if(leftDiag==2) return true;
    	
    	r1=0;
    	c1=2;
    	while(r1<2 && c1>0) {
    		if(isFirst && xoArray[r1][c1]==1 && xoArray[r1][c1]==xoArray[r1+1][c1-1]) {
    			rightDiag++;
    			r1++;
    			c1--;
    		}
    		else if(!isFirst && xoArray[r1][c1]==2 && xoArray[r1][c1]==xoArray[r1+1][c1-1]) {
    			rightDiag++;
    			r1++;
    			c1--;
    		}
    		else {
    			break;
    		}
    	}
    	if(rightDiag==2) return true;
        return false;
    }

    
    private void showMatrix() {
        System.out.println("\n\t  0   1   2");
        System.out.println("\t +---+---+---+");

        for (int i = 0; i < xoArray.length; i++) {
            System.out.print("\t" + i + "|");
            for (int j = 0; j < xoArray[i].length; j++) {
                if (xoArray[i][j] == 1) {
                    System.out.print(" X |");
                } else if (xoArray[i][j] == 2) {
                    System.out.print(" O |");
                } else {
                    System.out.print("   |");
                }
            }
            System.out.println("\n\t +---+---+---+");
        }
    }

    //Clearing the Board
    private void clearXOBoard() {
        for (int i = 0; i < xoArray.length; i++) {
            for (int j = 0; j < xoArray[i].length; j++) {
                xoArray[i][j] = 0;
            }
        }
    }
    
    //TO PRINT THE SCORE CARD OF ALL THE PLAYERS
    protected void printScoreCard() {
    	//If no players were registered at the beginning stage
        if (listOfPlayers.isEmpty()) {
      	  System.out.println("\n\t\t  THERE WERE NO MATCHES PLAYED..\n\n");
      	  return;
        }
        
        String[] headers = {"PLAYER NAME", "NO OF WINS", "NO OF LOSSES", "NO OF DRAWS"};
        int[] columnWidths = {15, 20, 20, 20};
//        boolean matchesPlayed = false;
        
        // PREPARE DATA FOR THE TABLE
        String[][] data = new String[listOfPlayers.size()][4];
        int idx = 0;
        for (Player p : listOfPlayers) {
            data[idx][0] = p.getName();
            data[idx][1] = String.valueOf(playerWinMap.getOrDefault(p.getPlayerId(), 0));
            data[idx][2] = String.valueOf(p.getTotalGamesPayed() - playerWinMap.getOrDefault(p.getPlayerId(), 0));
            data[idx][3] = String.valueOf(p.getTotalDraws());
            idx++;
        }

        // PRINTING THE TABLE
        Main.printTable(headers, columnWidths, data);
    }

    // TO VIEW ALL THE PLAYERS
    void printAllPlayers() {
        System.out.println("\t" + Main.printBoundary(6) + "\t\t" + Main.printBoundary(10));
        System.out.println("\t  ID" + "\t\t  NAME");
        System.out.println("\t" + Main.printBoundary(6) + "\t\t" + Main.printBoundary(10));
        if (listOfPlayers.size() == 0) {
            System.out.println("\t  THERE ARE NO PLAYERS AVAILABLE\t\t\n");
            return;
        }
        for (Player p : listOfPlayers) {
            System.out.println("\t  " + p.getPlayerId() + "\t\t  " + p.getName());
        }
    }

    // TO GET A PARTICULAR PLAYER BY NAME
    protected Player getPlayer(String playerName) {
        clearXOBoard();
        Player currentPlayer = null;
        while (currentPlayer == null) {
            for (Player p : listOfPlayers) {
                if (p.getName().equals(playerName)) {
                    currentPlayer = p;
                    break;
                }
            }
            if (currentPlayer == null) {
                System.out.println("\n\tPlease enter a valid name..\n");
            }
        }
        return currentPlayer;
    }
}

class TimeLimitExceededException extends Exception {
	public TimeLimitExceededException(String msg) {
		super(msg);
	}
}

