package App;

import java.util.*;

import App.GameManager.Log;

public class GameManager {
    static class Log {
        Player p1, p2, whoWon;
        private boolean isDraw = false;
        public boolean isDraw() {
			return isDraw;
		}
		public void setDraw(boolean isDraw) {
			this.isDraw = isDraw;
		}
		public Log(Player p1, Player p2, Player whoWon) {
            this.p1 = p1;
            this.p2 = p2;
            this.whoWon = whoWon;
        }
    }

    Map<Integer, Integer> playerWinMap;
    Set<Player> listOfPlayers;
    static Stack<Log> stackHistory;

    public GameManager() {
        playerWinMap = new HashMap<>();
        listOfPlayers = new HashSet<>();
        stackHistory = new Stack<Log>();
    }

    static int[][] xoArray = new int[3][3];

    private Player checkIfPlayerExists(String name) {
        Player t = null;
        for (Player p : listOfPlayers) {
            if (p.getName().equals(name)) {
                t = p;
                return t;
            }
        }
        return t;
    }

    void playGame() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter player 1 name");
        String player1 = sc.next();

        Player p1 = checkIfPlayerExists(player1);
        if (p1 == null) {
            p1 = new Player(player1);
            listOfPlayers.add(p1);
        }

        System.out.println("Enter player 2 name");
        String player2 = sc.next();

        Player p2 = checkIfPlayerExists(player2);
        if (p2 == null) {
            p2 = new Player(player2);
            listOfPlayers.add(p2);
        }
        startGame(p1, p2);
    }

    protected void startGame(Player p1, Player p2) {
        Scanner sc = new Scanner(System.in);
        showMatrix();

        for (int i = 0; i < 9; i++) {
            Player currentPlayer = (i % 2 == 0) ? p1 : p2;
            System.out.println("\n\tEnter the choice for " + currentPlayer.getName() +
                    " (As in coordinates => r,c )\n");
            
            int row = 0;
            int col = 0;
            boolean validInput = false;

            while (!validInput) {
                try {
                    String coordinate = sc.next();
                    row = Integer.valueOf(coordinate.split(",")[0]);
                    col = Integer.valueOf(coordinate.split(",")[1]);

                    System.out.println("r: " + row + ", c: " + col);

                    validInput = isValid(row, col);
                    if (!validInput) {
                        System.out.println("\tPlease select a valid choice.");
                    }
                } catch (Exception e) {
                    System.out.println("\tInvalid input. Please enter coordinates in the format 'r,c'.");
//                    System.out.println("\tException occurred: "+e.getMessage());
                }
            }

            xoArray[row][col] = (i % 2 == 0) ? 1 : 2;

            showMatrix();

            if (i > 2 && check(row, col)) {
                Player loss1 = null;
                if (currentPlayer.getName().equals(p1.getName())) {
                    loss1 = p1;
                    int loss = p1.getTotalLosses();
                    p1.setTotalLosses(loss + 1);
                } else {
                    loss1 = p2;
                    int loss = p2.getTotalLosses();
                    p2.setTotalLosses(loss + 1);
                }
                System.out.println(currentPlayer.getName() + " wins");

                if (p2.getName().equals(currentPlayer.getName())) {
                    stackHistory.push(new Log(currentPlayer, p1, currentPlayer));
                } else {
                    stackHistory.push(new Log(currentPlayer, p2, currentPlayer));
                }

                int totalWins = playerWinMap.getOrDefault(currentPlayer.getPlayerId(), 0);
                playerWinMap.put(currentPlayer.getPlayerId(), totalWins + 1);

                System.out.println("\n\n");

                Iterator<Player> iterator = listOfPlayers.iterator();
                while (iterator.hasNext()) {
                    Player p = iterator.next();

                    String pt1 = p1.getName();
                    String pt2 = p2.getName();

                    if (p.getName().equals(pt1)) {
//                        System.out.println("In p1::" + p.getTotalGamesPayed());
                        int gamesPlayedByP1 = p.getTotalGamesPayed();
                        p.setTotalGamesPayed(gamesPlayedByP1 + 1);

                        if (loss1.getName().equals(p)) {
                            p.setTotalLosses(loss1.getTotalLosses());
                        }
                    } else if (p.getName().equals(pt2)) {
//                        System.out.println("In p2::" + p.getTotalGamesPayed());
                        int gamesPlayedByP2 = p.getTotalGamesPayed();
                        p.setTotalGamesPayed(gamesPlayedByP2 + 1);

                        if (loss1.getName().equals(p)) {
                            p.setTotalLosses(loss1.getTotalLosses());
                        }
                    }
                }

                clearXOBoard();
//                showMatrix();
                return;
            }

        }
        Iterator<Player> iterator = listOfPlayers.iterator();
        while (iterator.hasNext()) {
            Player pl = iterator.next();
            if (pl.getName().equals(p1.getName())) {
                int currentDrawsForP1 = pl.getTotalDraws();
                pl.setTotalDraws(currentDrawsForP1 + 1);
            } else if (pl.getName().equals(p2.getName())) {
                int currentDrawsForP2 = pl.getTotalDraws();
                pl.setTotalDraws(currentDrawsForP2 + 1);
            }
        }
        clearXOBoard();
        Log g = new Log(p1, p2, null);
        g.setDraw(true);
        stackHistory.push(g);
        System.out.println("\n It's a DRAW !!");
    }

    //TO CHECK, IF THE (r,c) IS WITHIN THE RANGE
    private boolean isValid(int row, int col) {
        return row >= 0 && row < 3 && col >= 0 && col < 3 && xoArray[row][col] == 0;
    }

    private boolean check(int row, int col) {
    	// Check the rows from left - ri8
    	int countR = 0;
    	for(int i=0;i<2;i++) {
    		if(xoArray[row][i] == xoArray[row][i+1]) {
    			countR++;
    		}
    	}
    	if(countR==2) return true;
    	
        // Check the columns from top - bottom
    	int countC = 0;
    	for(int i=0;i<2;i++) {
    		if(xoArray[i][col] == xoArray[i+1][col] && xoArray[i][col] != 0 && xoArray[i+1][col] != 0) {
    			countC++;
    		}
    	}
    	if(countC==2) return true;

        // Check the diagonals from cross or mid
        if ((xoArray[0][0] == xoArray[1][1] && xoArray[1][1] == xoArray[2][2]
                || xoArray[0][2] == xoArray[1][1] && xoArray[1][1] == xoArray[2][0]) && xoArray[1][1] != 0) {
            return true;
        }

        return false;
    }

    
    private void showMatrix() {
        System.out.println("\n\t  0   1   2");
        System.out.println("\t +---+---+---+");

        for (int i = 0; i < xoArray.length; i++) {
            System.out.print("\t" + i + "|");
            for (int j = 0; j < xoArray[i].length; j++) {
                if (xoArray[i][j] == 1) {
                    System.out.print(" X |");
                } else if (xoArray[i][j] == 2) {
                    System.out.print(" O |");
                } else {
                    System.out.print("   |");
                }
            }
            System.out.println("\n\t +---+---+---+");
        }
    }

    //Clearing the Board
    private void clearXOBoard() {
        for (int i = 0; i < xoArray.length; i++) {
            for (int j = 0; j < xoArray[i].length; j++) {
                xoArray[i][j] = 0;
            }
        }
    }
    
    //TO PRINT THE SCORE CARD OF ALL THE PLAYERS
    protected void printScoreCard() {
    	//If no players were registered at the beginning stage
        if (listOfPlayers.isEmpty()) {
      	  System.out.println("\n\t\t  THERE WERE NO MATCHES PLAYED..\n\n");
      	  return;
        }
        
        String[] headers = {"PLAYER NAME", "NO OF WINS", "NO OF LOSSES", "NO OF DRAWS"};
        int[] columnWidths = {15, 20, 20, 20};
//        boolean matchesPlayed = false;
        
        // Prepare data for the table
        String[][] data = new String[listOfPlayers.size()][4];
        int idx = 0;
        for (Player p : listOfPlayers) {
//          if (playerWinMap.get(p.getPlayerId()) == null) {
//	          System.out.println("\t  " + p.getName() + "\t\t\t\t  0\t\t\t    " + p.getTotalGamesPayed() + "\t\t" + p.getTotalDraws() + "\n\n");
//	          matchesPlayed = true;
//	      } else {
//	          for (Integer pid : playerWinMap.keySet()) {
//	              if (pid == p.getPlayerId()) {
//	                  System.out.println("\t  " + p.getName() + "\t\t\t\t  " + playerWinMap.getOrDefault(pid, 0) + "\t\t\t    " + (p.getTotalGamesPayed() - playerWinMap.getOrDefault(p.getPlayerId(), 0)) + "\t\t" + p.getTotalDraws() + "\n\n");
//	                  matchesPlayed = true;
//	                  break;
//	              }
//	          }
//	      }
            data[idx][0] = p.getName();
            data[idx][1] = String.valueOf(playerWinMap.getOrDefault(p.getPlayerId(), 0));
            data[idx][2] = String.valueOf(p.getTotalGamesPayed() - playerWinMap.getOrDefault(p.getPlayerId(), 0));
            data[idx][3] = String.valueOf(p.getTotalDraws());
            idx++;
        }

        // Print the table
        Main.printTable(headers, columnWidths, data);
    }

    
    void printAllPlayers() {
        System.out.println("\t" + Main.printBoundary(6) + "\t\t" + Main.printBoundary(10));
        System.out.println("\t  ID" + "\t\t  NAME");
        System.out.println("\t" + Main.printBoundary(6) + "\t\t" + Main.printBoundary(10));
        if (listOfPlayers.size() == 0) {
            System.out.println("\t  THERE ARE NO PLAYERS AVAILABLE\t\t\n");
            return;
        }
        for (Player p : listOfPlayers) {
            System.out.println("\t  " + p.getPlayerId() + "\t\t  " + p.getName());
        }
    }

    protected Player getPlayer(String playerName) {
        clearXOBoard();
        Player currentPlayer = null;
        while (currentPlayer == null) {
            for (Player p : listOfPlayers) {
                if (p.getName().equals(playerName)) {
                    currentPlayer = p;
                    break;
                }
            }
            if (currentPlayer == null) {
                System.out.println("\n\tPlease enter a valid name..\n");
            }
        }
        return currentPlayer;
    }
}
