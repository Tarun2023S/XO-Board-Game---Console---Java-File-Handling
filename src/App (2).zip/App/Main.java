package App;
import java.util.*;
public class Main {
	
	private static int validChoices() {
		int choice=0 ;
		System.out.println("\t\t"+printBoundary(20));
		System.out.println("\n\t\t Enter Your Choice\n");
		System.out.println("\t\t"+printBoundary(20));
		System.out.println("  1. Play game\n  2. Print All Score Cards\n  3. REDO USING SET \n  4. Exit\n");
		lastPlayedGameInfo();
		Scanner sc = new Scanner(System.in);
		try {
		 choice = sc.nextInt();	
		}
		catch(Exception e) {
			System.out.println(" Please enter a valid choice\n");
			validChoices();
		}
		return choice;
	}
	
	static String printBoundary(int a) {
		return ""+String.valueOf('-').repeat(a);
	}
	
	private static void lastPlayedGameInfo() {
		System.out.println("\t\t"+printBoundary(26));
		System.out.println("\t\t  Last Played Game Info");
		System.out.println("\t\t"+printBoundary(26));
		System.out.println();
		if(GameManager.stackHistory.isEmpty()) {
			System.out.println("\t\tThere were no last played games..");
		}
		else {
			System.out.println(""+printBoundary(13)+"\t\t"+printBoundary(17)+"\t"+printBoundary(10));
			System.out.println(" Player name\t\t  Opponent name\t\t  Winner");
			System.out.println(""+printBoundary(13)+"\t\t"+printBoundary(17)+"\t"+printBoundary(10));
			GameManager.Log obj = GameManager.stackHistory.peek();
			System.out.println("\t"+obj.p1.getName()+"\t\t\t"+obj.p2.getName()+"\t\t  "+obj.whoWon.getName());
		}
	}
	
	public static void main(String[] args) {
		boolean loop = true;
		GameManager gm = new GameManager();
		Scanner sc = new Scanner(System.in);
		while(loop) {
//			System.out.println("\t"+printBoundary(13));
//			System.out.println("\t\tGAME STARTS");
			int choice = validChoices();
			switch(choice) {
				case 1: {
					gm.playGame();
				}
				break;
				case 2: {
					gm.printScoreCard();
				}
				break;
				case 3: {
					gm.printAllPlayers();
					System.out.println("Enter the Id's of the players");
					int id1 = sc.nextInt();
					Player p1 = gm.getPlayer(id1);
					int id2 = sc.nextInt();
					Player p2 = gm.getPlayer(id2);
					gm.startGame(p1, p2);
				}
				break;
				case 4: {
					System.out.println("\t\tThank you for your time..");
					loop = false;
				}
				break;
				default: {
					System.out.println("Please enter a valid case number");
				}
				break;
			}
		}

	}

}
