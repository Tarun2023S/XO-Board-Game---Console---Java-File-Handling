package App;
import java.util.*;

public class GameManager {
	static class Log {
		Player p1, p2, whoWon;
		public Log(Player p1, Player p2, Player whoWon) {
			this.p1 = p1;
			this.p2 = p2;
			this.whoWon = whoWon;
		}
	}
    Map<Integer, Integer> playerWinMap;
    Set<Player> listOfPlayers;
    static Stack<Log> stackHistory;
    
    public GameManager() {
        playerWinMap = new HashMap<>();
        listOfPlayers = new HashSet<>();
//        listOfPlayers.add(new Player("helli"));
//        playerWinMap.put(null, null)
        stackHistory = new Stack();
    }

    static int[][] xoArray = new int[3][3];

    private boolean checkIfPlayerExists(String name) {
        for (Player p : listOfPlayers) {
            if (p.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    void playGame() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter player 1 name");
        String player1 = sc.next();

        while(checkIfPlayerExists(player1)) {
        	System.out.println("\t\tThat name already exists..\n\t\tPlease try using a different name..");
        	player1 = sc.next();
        }

        Player p1 = new Player(player1);
        listOfPlayers.add(p1);
        System.out.println("Enter player 2 name");
        String player2 = sc.next();

        while(checkIfPlayerExists(player2)) {
        	System.out.println("\t\tThat name already exists..\n\t\tPlease try entering a different name..");
        	player2 = sc.next();
        }
        Player p2 = new Player(player2);
        listOfPlayers.add(p2);
        startGame(p1, p2);
    }

    protected void startGame(Player p1, Player p2) {
        Scanner sc = new Scanner(System.in);
        showMatrix();
        
        for (int i = 0; i < 9; i++) {
            Player currentPlayer = (i % 2 == 0) ? p1 : p2;
            System.out.println("\n\tEnter the choice for " + currentPlayer.getName() +
                    " (As in coordinates => r,c )\n");
            String coordinate = sc.next();
            System.out.println("cord:"+coordinate.split(",")[0]);
            int row = Integer.valueOf(coordinate.split(",")[0]);
            int col = Integer.valueOf(coordinate.split(",")[1]);
//            if(coordinate.split(",")[0]) >= 48) {
//            	
//            }
//            System.out.println("cord:"+coordinate.split(",")[0]);
            System.out.println("r: "+row+", c: "+col);
//            System.out.println(""+row+", "+col);
            while (!isValid(row, col)) {
                System.out.println("\tPlease select a valid choice.");
                coordinate = sc.next();
                row = Integer.valueOf(coordinate.split(",")[0]);
                col = Integer.valueOf(coordinate.split(",")[1]);
            }

            xoArray[row][col] = (i % 2 == 0) ? 1 : 2;

            showMatrix();

            if (check(row, col)) {
            	Player loss1 = null;
            	if(currentPlayer.getName().equals(p1.getName())) {
            		loss1 = p1;
            		int loss = p1.getTotalLosses();
            		p1.setTotalLosses(loss+1);
            	}
            	else {
            		loss1 = p2;
            		int loss = p2.getTotalLosses();
            		p2.setTotalLosses(loss+1);
            	}
                System.out.println(currentPlayer.getName() + " wins"+currentPlayer.getTotalGamesPayed());
                
                if(p2.getName().equals(currentPlayer.getName())) {
                	stackHistory.push(new Log(currentPlayer, p1, currentPlayer));
                } else {
                	stackHistory.push(new Log(currentPlayer, p2, currentPlayer));
                }
                
//              
//                	System.out.println("IN111111");
                	int totalWins = playerWinMap.getOrDefault(currentPlayer.getPlayerId(), 0);
                	playerWinMap.put(currentPlayer.getPlayerId(), totalWins + 1);
//                	System.out.println("TotWins: "+playerWinMap.getOrDefault(currentPlayer.getPlayerId(), 0));
//                

//                	for(Player p: listOfPlayers) {
//                		System.out.println(p.getName()+": "+p.getTotalGamesPayed()+", wins: "+p.getTotalWins()+", loss: "+p.getTotalLosses()+"");
//                	}
                	System.out.println("\n\n");
                //Incrementing the Game Experience of the players
                for(Player p: listOfPlayers) {
                	String pt1 = p1.getName();
                	String pt2 = p2.getName();
                	if(p.getName().equals(pt1)) {
                		System.out.println("In p1::"+p.getTotalGamesPayed());
                		Player temp = p;
                		int gamesPlayedByP1 = p.getTotalGamesPayed();
                		temp.setTotalGamesPayed(gamesPlayedByP1 + 1);
                		
                		if(loss1.getName().equals(p)) {
                			temp.setTotalLosses(loss1.getTotalLosses());
                			listOfPlayers.remove(p);
                			listOfPlayers.add(temp);
                		}
                	}
                	else if(p.getName().equals(pt2)) {
                		System.out.println("In p2::"+p.getTotalGamesPayed());
                		Player temp = p;
                		int gamesPlayedByP2 = p.getTotalGamesPayed();
                		temp.setTotalGamesPayed(gamesPlayedByP2 + 1);
                		if(loss1.getName().equals(p)) {
                			temp.setTotalLosses(loss1.getTotalLosses());
                			listOfPlayers.remove(p);
                			listOfPlayers.add(temp);
                		}
                	}
                }
                clearXOBoard();
                showMatrix();
                return;
            }
            
            //showMatrix();
        }

        System.out.println("\n It's a DRAW !!");
    }

    private boolean isValid(int row, int col) {
        if (row >= 0 && row < 3 && col >= 0 && col < 3 && xoArray[row][col] == 0) {
            return true;
        }
        return false;
    }

    private boolean check(int row, int col) {
    	// Check the rows from left - ri8
    	int countR = 0;
    	for(int i=0;i<2;i++) {
    		if(xoArray[row][i] == xoArray[row][i+1]) {
    			countR++;
    		}
    	}
    	
//    	System.out.println("X/O:");
//    	System.out.println(Arrays.toString(xoArray));
//    	System.out.println();
    	if(countR==2) return true;
    	
        // Check the columns from top - bot
    	int countC = 0;
    	for(int i=0;i<2;i++) {
    		if(xoArray[i][col] == xoArray[i+1][col] && xoArray[i][col] != 0 && xoArray[i+1][col] != 0) {
    			countC++;
    		}
    	}
    	if(countC==2) return true;

        // Check the diagonals from cross or mid
        if ((xoArray[0][0] == xoArray[1][1] && xoArray[1][1] == xoArray[2][2]
                || xoArray[0][2] == xoArray[1][1] && xoArray[1][1] == xoArray[2][0]) && xoArray[1][1] != 0) {
            return true;
        }

        return false;
    }

    private void showMatrix() {
//    	System.out.println(Arrays.toString(xoArray));
        for (int i = 0; i < xoArray.length; i++) {
            for (int j = 0; j < xoArray[i].length; j++) {
                if (xoArray[i][j] == 1) {
                    System.out.print("  X");
                } else if (xoArray[i][j] == 2) {
                    System.out.print("  O");
                } else {
                    System.out.print("  _");
                }
            }
            System.out.println();
        }
//    	System.out.println(Arrays.toString(xoArray));
        
    }
    
    private void clearXOBoard() {
    	for(int i=0;i<xoArray.length;i++) {
    		for(int j=0;j<xoArray[i].length;j++) {
    			xoArray[i][j] = 0;
    		}
    	}
//    	System.out.println(Arrays.toString(xoArray));
    }
    
    protected void printScoreCard() {
//    	printAllPlayers();
//    	System.out.println("\n\tEnter the player id you want to see the Score card details..");
//    	Scanner sc = new Scanner(System.in);
//    	int playerId = sc.nextInt();
//    	Player currentPlayer = getPlayer(playerId);
    	
//    	String playerName = "";
//    	Player currentPlayer = null;
//    	while(currentPlayer==null) {
//    		for(Player p: listOfPlayers) {
//        		if(p.getPlayerId() == playerId) {
//        			currentPlayer = p;
//        			playerName = p.getName();
//        			System.out.println("p: Tot: "+p.getTotalGamesPayed());
//        			break;
//        		}
//        	}
//    		if(currentPlayer==null) {
//    			System.out.println("\n\tPlease enter an valid id..\n");
//    		}
//    	}
//    	System.out.println("Totals: "+currentPlayer.getTotalGamesPayed());
    	
    	System.out.println("\t"+Main.printBoundary(10)+"\t\t"+Main.printBoundary(20)+"\t"+Main.printBoundary(20));
		System.out.println("\tPLAYER NAME"+"\t\t   NO OF WINS"+"\t\t    NO OF LOSSES");
		System.out.println("\t"+Main.printBoundary(10)+"\t\t"+Main.printBoundary(20)+"\t"+Main.printBoundary(20));

		boolean matchesPlayed = false;
		
    	for(Player p: listOfPlayers) {
    		if(playerWinMap.get(p.getPlayerId())==null) {
        		System.out.println("\t  "+p.getName()+"\t\t\t\t  0\t\t\t    "+p.getTotalGamesPayed()+"\n\n");
        		matchesPlayed = true;
    		}
    		else {
    			for(Integer pid: playerWinMap.keySet()) {
    	    		if(pid == p.getPlayerId()) {
    	    			System.out.println("\t  "+p.getName()+"\t\t\t\t  "+playerWinMap.getOrDefault(pid, 0)+"\t\t\t    "+(p.getTotalGamesPayed()-playerWinMap.getOrDefault(p.getPlayerId(), 0))+"\n\n");
    	    			matchesPlayed = true;
    	    			break;
    	    		}
    	    	}
    		}
    	}
    	if(!matchesPlayed) {
    		System.out.println("\t\t\t\t  THERE WERE NO MATCHES PLAYED\n\n");
    	}
//       	if(playerWinMap.get(currentPlayer.getPlayerId())==null) {
//    		System.out.println("\t  "+currentPlayer.getName()+"\t\t\t\t  0\t\t\t    "+currentPlayer.getTotalGamesPayed()+"\n\n");
//    		return;
//    	}
//    	for(Integer pid: playerWinMap.keySet()) {
//    		if(pid == playerId) {
//    			System.out.println("\t  "+currentPlayer.getName()+"\t\t\t\t  "+playerWinMap.getOrDefault(pid, 0)+"\t\t\t    "+(currentPlayer.getTotalGamesPayed()-playerWinMap.getOrDefault(pid, 0))+"\n\n");
//    			break;
//    		}
//    	}
    }
    
    void printAllPlayers() {
    	System.out.println("\t"+Main.printBoundary(6)+"\t\t"+Main.printBoundary(10));
		System.out.println("\t  ID"+"\t\t  NAME");
		System.out.println("\t"+Main.printBoundary(6)+"\t\t"+Main.printBoundary(10));
		if(listOfPlayers.size()==0) {
			System.out.println("\t  THERE ARE NO PLAYERS AVAILABLE\t\t\n");
			return;
		}
    	for(Player p: listOfPlayers) {
    		System.out.println("\t  "+p.getPlayerId()+"\t\t  "+p.getName());
    	}
    }
    
    protected Player getPlayer(int playerId) {
    	clearXOBoard();
    	Scanner sc = new Scanner(System.in);
    	String playerName = "";
    	Player currentPlayer = null;
    	while(currentPlayer==null) {
    		for(Player p: listOfPlayers) {
        		if(p.getPlayerId() == playerId) {
        			currentPlayer = p;
        			playerName = p.getName();
        			System.out.println("p: Tot: "+p.getTotalGamesPayed());
        			break;
        		}
        	}
    		if(currentPlayer==null) {
    			System.out.println("\n\tPlease enter an valid id..\n");
    		}
    	}
    	return currentPlayer;
    }
}


