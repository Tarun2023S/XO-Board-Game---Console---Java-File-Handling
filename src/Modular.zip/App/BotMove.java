package App;

import java.util.Arrays;

public class BotMove {
	 private static boolean isLeftDiagonalMarked = false;
	 private static boolean isRightDiagonalMarked = false;
	 private static int[] rowWiseMarked;
	 private static int[] colWiseMarked;
	 int[] getBotMove(int[][] board, int botSymbol) {
        int[] result = new int[]{-1, -1};
        
        // Check for a winning move for the bot
        result = checkWinningMove2(board, botSymbol);

        if (result[0] == -1 && result[1] == -1) {
            // If no winning move, check for a blocking move for the player
            int playerSymbol = (botSymbol == 1) ? 2 : 1;
            result = checkWinningMove2(board, playerSymbol);
        }

        // If no winning or blocking move, choose the adjacent max consecutive 2's available in an empty cell
        if (result[0] == -1 || result[1] == -1) {
        	result = getNextToMaxConsecutiveTwos(board, 2);
        }
        // If no winning or blocking move, choose the first available empty cell
        if (result[0] == -1 || result[1] == -1) {
        	System.out.println("Deep arr: "+Arrays.deepToString(board));
            for (int i = 0; i < board.length; i++) {
                for (int j = 0; j < board.length; j++) {
                	System.out.println("In nowinnolossMove");
//                	System.out.println("b[i][j]: "+board[i][j]);
                    if (board[i][j] == 0) {
                    	System.out.println("In bb[0]: "+board[0]);
                    	System.out.println("In bb[0]: "+board[1]);
                    	result[0] = i;
                    	result[1] = j;
                    	return result;
                    }
                }
            }
        }
        for(int[] r: board) {
        	System.out.println(Arrays.toString(r));
        }
       
        return result;
    }
	
	 private int[] checkWinningMove2(int[][] board, int symbol) {
	    	int consec = 0, noOfSymbols = 0, missing = -1, gap = -1;
	    	int res[] = new int[2];
	    	res[0] = -1;
	    	res[1] = -1;
	    	int expectedNumberOfSymbols = board[0].length - 1;
	    	// ROW WISE CHECK
	    	for (int i = 0; i < board.length; i++) {
	    	    consec = 0;
	    	    noOfSymbols = 0;
	    	    missing = -1;
	    	    gap = -1;

	    	    // ROW WISE CHECK GAP
	    	    for (int j = 0; j < board[i].length; j++) {
	    	        if (board[i][j] == symbol) {
	    	            noOfSymbols++;
	    	        } else if (board[i][j] == 0) {
	    	            gap = j;
	    	        }
	    	    }

	    	    if (noOfSymbols == expectedNumberOfSymbols && gap != -1) {
	    	        System.out.println("IN gap sym");
	    	        if (board[i][gap] == 0) {
	    	            res[0] = i;
	    	            res[1] = gap;
//	    	            System.out.println("Res: Through Rgap1 " + Arrays.toString(res));
	    	            return res;
	    	        }
	    	    }
	    	}

	    	// COLUMN WISE CHECK
	    	for (int j = 0; j < board[0].length; j++) {
	    	    consec = 0;
	    	    noOfSymbols = 0;
	    	    missing = -1;
	    	    gap = -1;

	    	    // COLUMN WISE CHECK GAP
	    	    for (int i = 0; i < board.length; i++) {
	    	        if (board[i][j] == symbol) {
	    	            noOfSymbols++;
	    	        } else if (board[i][j] == 0) {
	    	            gap = i;
	    	        }
	    	    }

	    	    if (noOfSymbols == expectedNumberOfSymbols && gap != -1) {
	    	        System.out.println("IN gap sym");
	    	        if (board[gap][j] == 0) {
	    	            res[0] = gap;
	    	            res[1] = j;
	    	            return res;
	    	        }
	    	    }
	    	}

	    	// Check diagonals
	        int r=0, c=0;
	        noOfSymbols = 0;
	        int totalRows = board.length, totalCols = board[0].length;
	        int[] miss = {-1, -1};
	        System.out.println("Diag wise Check");
	        while(r<totalRows && c<totalCols) {
	        	if(board[r][c]==symbol) {
	        		noOfSymbols++;
	        	}
	        	else {
	        		miss[0] = r;
	        		miss[1] = c;
	        	}
	        	if(board[r][c]==1) isLeftDiagonalMarked = true;
	        	r++;
	        	c++;
	        }
	        if (noOfSymbols == expectedNumberOfSymbols && miss[0] != -1) {
		        System.out.println("IN gap sym");
		        if (board[miss[0]][miss[1]] == 0) {
		            return miss;
		        }
		    }
	        
	        r=0;
	        c=board.length-1;
	        noOfSymbols = 0;
	        miss[0] = -1;
	        miss[1] = -1;
	        System.out.println("Diag wise Check 2");
	        while(r>=0 && c>=0) {
	        	if(board[r][c]==symbol) {
	        		noOfSymbols++;
	        		System.out.println("r: "+r+", c: "+c);
	        	}
	        	else {
	        		miss[0] = r;
	        		miss[1] = c;
	        	}
	        	if(board[r][c]==1) isRightDiagonalMarked = true;
	        	r++;
	        	c--;
	        }
	        
	        System.out.println("noOfSym: "+noOfSymbols);
	        if (noOfSymbols == expectedNumberOfSymbols && miss[0] != -1) {
		        System.out.println("IN gap sym");
		        if (board[miss[0]][miss[1]] == 0) {
		            return miss;
		        }
		    }
	        return res;
	    }
	 
	 private static int[] getNextToMaxConsecutiveTwos(int[][] board, int symbol) {
		    int maxConsecutiveTwos = -1;
		    int[] result = new int[] {-1, -1};
		    int[] maxConsecSym = new int[1];
		    // Iterate over the board to find the cell with the maximum consecutive 2's
		    for (int i = 0; i < board.length; i++) {
		        for (int j = 0; j < board[0].length; j++) {
		            if (board[i][j] == 0) {
//		                int consecutiveTwos = countConsecutiveTwos(board, i, j, symbol);
//		                if (consecutiveTwos > maxConsecutiveTwos) {
//		                    maxConsecutiveTwos = consecutiveTwos;
//		                    result[0] = i;
//		                    result[1] = j;
//		                }
		            	countConsecutiveTwos2(board, i, j, symbol, result, maxConsecSym);
		            }
		        }
		    }

		    return result;
		}

		private static int countConsecutiveTwos(int[][] board, int row, int col, int symbol) {
		    // Count consecutive 2's horizontally, vertically, and diagonally
		    int count = 0;

		    // Check horizontally
		    for (int i = -1; i <= 1; i++) {
		        if (col + i >= 0 && col + i < board[0].length && board[row][col + i] == symbol) {
		            count++;
		        }
		    }

		    // Check vertically
		    for (int i = -1; i <= 1; i++) {
		        if (row + i >= 0 && row + i < board.length && board[row + i][col] == symbol) {
		            count++;
		        }
		    }

		    // Check diagonally
		    for (int i = -1; i <= 1; i++) {
		        for (int j = -1; j <= 1; j++) {
		            if (row + i >= 0 && row + i < board.length && col + j >= 0 && col + j < board[0].length && board[row + i][col + j] == symbol) {
		                count++;
		            }
		        }
		    }

		    return count;
		}
		
		private static void countConsecutiveTwos2(int[][] board, int row, int col, int symbol, int[] pos, int[] maxConecSym) {
			int tempR = row, tempC = col, r = 0, c = 0, totalRowCount=0, totalColCount=0;
			int consecSym=0;
			int leftDiag=0, rightDiag=0;
			//Row wise check from the current idx
			while(tempC-1>=0 && board[row][tempC-1]==2) {
				tempC--;
				r++;
			}
			tempC = col;
			while(tempC+1<board.length && board[row][tempC+1]==2) {
				tempC++;
				r++;
			}
			totalRowCount = Math.max(totalRowCount, r);
			
			//Column wise check from the current idx
			while(tempR-1>=0 && board[tempR-1][col]==2) {
				tempR--;
				c++;
			}
			tempC = col;
			while(tempR+1<board.length && board[tempR][col]==2) {
				tempR++;
				c++;
			}
			totalColCount = Math.max(totalColCount, c);
//			if(rowWiseMarked[row]==1 && colWiseMarked[col]==0) {
//				if(totalColCount > totalRowCount) {
//					consecSym = 
//				}
//			}
			consecSym = Math.max(consecSym, Math.max(totalRowCount, totalColCount));
			if(consecSym > maxConecSym[0]) {
				pos[0] = row;
				pos[1] = col;
				maxConecSym[0] = consecSym;
			}
			
			//If its a part of the diagonals
			int[] miss = new int[] {-1, -1};
			if(row==col && !isLeftDiagonalMarked) {
				tempR=0;
				tempC=0;
		        System.out.println("Diag wise Check 2");
		        while(tempR<board.length && tempC<board.length) {
		        	if(board[tempR][tempC]==symbol) {
		        		leftDiag++;
		        	}
		        	else if(board[tempR][tempR]==0){
		        		miss[0] = tempR;
		        		miss[1] = tempC;
		        	}
		        	tempR++;
		        	tempC++;
		        }
		        if(leftDiag > maxConecSym[0] && miss[0]!=-1) {
		        	pos[0] = miss[0];
					pos[1] = miss[1];
					maxConecSym[0] = leftDiag;
				}
			}
			
			
			if(row+col==board.length-1 && !isRightDiagonalMarked) {
				tempR=0;
				tempC=board.length-1;
				miss = new int[] {-1, -1};
				while(tempR<board.length && tempC==0) {
		        	if(board[tempR][tempC]==symbol) {
		        		rightDiag++;
//		        		System.out.println("r: "+r+", c: "+c);
		        	}
		        	else if(board[tempR][tempC]==0){
		        		miss[0] = tempR;
		        		miss[1] = tempC;
		        	}
		        	tempR++;
		        	tempC--;
		        }
				if(rightDiag > maxConecSym[0] && miss[0]!=-1) {
		        	pos[0] = miss[0];
					pos[1] = miss[1];
					maxConecSym[0] = rightDiag;
				}
			}
			if(pos[0]==-1 || pos[1]==-1) {
				pos[0] = row;
				pos[1] = col;
			}
		}
}

